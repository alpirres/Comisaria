var contadorPIERDE=0//variable estatica para contar los puntos que pierde

/*
	funcion que crea un numero aleatorio entre 0-3 para elegir un signo matematico aleatorio,
	con ese numero entra en el sitch y segidamente vuelve a generar 2 numeros aleatorios para realizar la cuenta,
	a su vez se guarda el resultado para compararlo con lo que introduce el usuario.
*/
function generaSigno(){
	var aleatorio = Math.round(Math.random()*3);//numero aleatorio de 0-3
	var numero1
	var numero2
	var cuenta
	var resultado
	switch(aleatorio){
		case 0: 
			numero1=Math.round(Math.random()*1000);//numero aleatorio de 0-1000
			numero2=Math.round(Math.random()*1000);//numero aleatorio de 0-1000
			cuenta=numero1+"+"+numero2;
			resultado=numero1+numero2;
			break;
		case 1: 
			do{
				numero1=Math.round(Math.random()*1000);
				numero2=Math.round(Math.random()*1000);
			}while(numero1<numero2)// para que no salgan numero negativos
			cuenta=numero1+"-"+numero2;
			resultado=numero1-numero2;
			break;
		case 2: 
			numero1=Math.round(Math.random()*100);
			numero2=Math.round(Math.random()*10);
			cuenta=numero1+"x"+numero2;
			resultado=numero1*numero2;
			break;
		case 3: 
			do{
				numero1=Math.round(Math.random()*100);
				numero2=Math.round(Math.random()*10);
			}while(numero1%numero2!=0);//para que no salgan decimales
			cuenta=numero1+"/"+numero2;
			resultado=numero1/numero2;
			break;
	}
	document.getElementById("operacion").innerHTML=cuenta;
	document.getElementById("resultado").name=resultado;
}

/*
	Funcion que comprueba los resultados y si no es correcto pone el borde del imput a color rojo actualiz contador y finaliza el juego
*/
function compruebaNumeros(){
	
	if(resultado.name==resultado.value){//si acierta el resultado
		generaSigno();
		resultado.value="";
		resultado.style.borderColor="initial";//poner el color del borde al inicial
		var cuenta = parseInt(document.getElementById("puntos").innerHTML, 10);
		var x = document.getElementById("c");
		x.autoplay = true;
		x.load();
		cuenta++;
		document.getElementById("puntos").innerHTML=cuenta;
		if(parseInt(document.getElementById("puntos").innerHTML, 10)==5){
			cuerpo.innerHTML = ""; 
			h1.innerHTML=" YOU WINNN!!!!"
			volver.style.display="block"
			var x = document.getElementById("w");
			x.autoplay = true;
			x.load();
		}
	}else{
		resultado.style.borderColor="red";// pone el color del borde en rojo
		resultado.value="";
		var cuenta = parseInt(document.getElementById("puntos").innerHTML, 10);
		if(contadorPIERDE<2){
			var x = document.getElementById("l");
			x.autoplay = true;
			x.load();
		}
		cuenta--;
		document.getElementById("puntos").innerHTML=cuenta;
		contadorPIERDE++
		if(contadorPIERDE==3){ 
			cuerpo.innerHTML = ""; 
			h1.innerHTML=" HAS FALLADO 3 VECES!!!!!"
			volver.style.display="block"
			var x = document.getElementById("m");
			x.autoplay = true;
			x.load();
		}
		
	}
}
/*
	funcion que recarga la pagina cuando se pulsa volver a intentarlo
*/
function restaurar(){
	location.reload();
}
































