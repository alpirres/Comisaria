function desplegar(){ // Con esto desplegaremos o cerraremos el formulario
	
	var estado = document.getElementById("desplegable1").style.display;
        if (estado == "none" || estado == "null"){
            document.getElementById("desplegable1").style.display = "block";
        }else{
            document.getElementById("desplegable1").style.display = "none";            
        }
	
	
}



function cambioPago(metodo){ //Con esto mostraremos o esconderemos los elementos de cada metodo de pago
	
	switch(metodo){
		case "tarjeta":
		//console.log("Entrando 1");
			var estado = document.getElementById("tarjetaRel").style.display;
			if (estado == "none"|| estado == "null"){
				document.getElementById("tarjetaRel").style.display = "block";
			
			}
			var estado2 = document.getElementById("pass").style.display;
			if(estado2 == "block"){
				document.getElementById("pass").style.display = "none";
				//console.log("Ocultando pass");
			}
			break;
			
		case "paypal":
		//console.log("Entrando 2");
			var estado = document.getElementById("tarjetaRel").style.display;
			if (estado == "block"){
				document.getElementById("tarjetaRel").style.display = "none";
				
			}
			var estado2 = document.getElementById("pass").style.display;
			if(estado2 == "none"|| estado2 == "null"){
				document.getElementById("pass").style.display = "block";
				//console.log("Mostrando pass");
			}
		
		break;
        };
		
	
	
}

function validarFormulario(){ //Con esto comprobaremos si todo está listo para ser enviado
	var validation = false;
	console.log(checkNif());
	console.log(checkEmail());
	console.log(checkTitular());
	console.log(checkTarjeta());
	console.log(checkFechaM());
	console.log(checkFechaY());
	console.log(checkCvv());
	
	var checkbox = document.getElementById("terms").checked;
	var nodeList = document.getElementsByName("Tarjetas");
	var node = null;
	for (var i = 0; i < nodeList.length; i++) {
		if(nodeList[i].checked){
			node = nodeList[i];
		}
  }
	var activado = node.id;
	console.log(node.id);
	
	
	
	
	if(checkbox){
		if(node.id=="Mastercard"){
			if(checkTarjeta()&checkNif()&checkEmail()&checkTitular()&checkFechaM()&checkFechaY()&checkCvv()&&terms){
				validation=true;

			}else{
				alert("Faltan campos por rellenar o contienen errores");

			}
		}
		
		
			if(node.id=="Paypal"){
				if(checkNif()&checkEmail()&&terms){
					validation=true;

				}else{
					alert("Faltan campos por rellenar o contienen errores");

				}
			}
		

	}else{
		alert("Debes aceptar los términos y condiciones");
}
	
	

	return validation;
}

function checkTarjeta(){ // Con esto revisaremos si la tarjeta es válida y qué tipo es
	
	var revisa = /^4[0-9]{12}(?:[0-9]{3})?$/i;
	var remc = /^(5[1-5][0-9]{14}|2(22[1-9][0-9]{12}|2[3-9][0-9]{13}|[3-6][0-9]{14}|7[0-1][0-9]{13}|720[0-9]{12}))$/i;
	var text = document.getElementById("numeroTarjeta").value;
	var validation = false;
	if (revisa.test(text)){
		//console.log("numeroTarjeta bien");
		document.getElementById("numeroTarjeta").style.borderColor="initial";
		document.getElementById("msgNumTar").innerHTML="Visa ✔";
		document.getElementById("msgNumTar").style.color="green";
		validation = true;
		
	}else if(remc.test(text)){
		//console.log("numeroTarjeta bien");
		document.getElementById("numeroTarjeta").style.borderColor="initial";
		document.getElementById("msgNumTar").innerHTML="MasterCard ✔";
		document.getElementById("msgNumTar").style.color="green";
		validation = true;
		
	}else{
		document.getElementById("numeroTarjeta").style.borderColor="red";
		document.getElementById("msgNumTar").innerHTML="    ✖";
		document.getElementById("msgNumTar").style.color="red";
		
	}	
	
	return validation;
}

function checkNif(){ // Con esto comprobaremos si el DNI es valido
	
	var validation = false;
	var re = /^[0-9]{8}[TRWAGMYFPDXBNJZSQVHLCKET]$/i;
	if (re.test(document.getElementById("NIF").value)){
		//console.log("Nif bien");
		
		document.getElementById("NIF").style.borderColor="initial";
		document.getElementById("msgNif").innerHTML="✔";
		document.getElementById("msgNif").style.color="green";
		validation = true;
		
		
	}else{
		
		document.getElementById("NIF").style.borderColor="red";
		document.getElementById("msgNif").innerHTML="   ✖";
		document.getElementById("msgNif").style.color="red";
		
	}	
	
	return validation;
}

function checkEmail(){ // Con esto comprobaremos si el Email es valido

	var re1 = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/i;
	var validation = false;
	if (re1.test(document.getElementById("email").value)){
		//console.log("email bien");
		document.getElementById("email").style.borderColor="initial";
		document.getElementById("msgEmail").innerHTML="✔";
		document.getElementById("msgEmail").style.color="green";
		validation = true;
		
	}else{
		document.getElementById("msgEmail").innerHTML="   ✖";
		document.getElementById("email").style.borderColor="red";
		document.getElementById("msgEmail").style.color="red";
		
	}	
	
	return validation;
}

function checkTitular(){ // Con esto comprobaremos si el Titular de la tarjeta es valido
	
	var re2 = /^[a-z ,.'-]+$/i;
	var validation = false;
	//console.log("ENTRANDOOO");
	if (re2.test(document.getElementById("nombreTitular").value)){
		document.getElementById("nombreTitular").style.borderColor="initial";
		document.getElementById("msgTitTar").innerHTML="✔";
		document.getElementById("msgTitTar").style.color="green";
		validation = true;
		
	}else{
		document.getElementById("msgTitTar").innerHTML="   ✖";
		document.getElementById("nombreTitular").style.borderColor="red";
		document.getElementById("msgTitTar").style.color="red";
		
	}
	
	return validation;
}

function checkFechaM(){ // Con esto comprobaremos si el Mes de expiracion es valido
	
	var re4 = /^(^0?[1-9]$)|(^1[0-2]$)/;
	var validation = false;
	if (re4.test(document.getElementById("numeroDeExpM").value)){
		//console.log("numeroDeExpM bien");
		document.getElementById("numeroDeExpM").style.borderColor="initial";
		document.getElementById("msgFechaMY").innerHTML="✔";
		document.getElementById("msgFechaMY").style.color="green";
		validation = true;
		
	}else{
		document.getElementById("msgFechaMY").innerHTML="   ✖";
		document.getElementById("numeroDeExpM").style.borderColor="red";
		document.getElementById("msgFechaMY").style.color="red";
		
	}
	
	return validation;
}

function checkFechaY(){ // Con esto comprobaremos si el Año de expiracion es valido
	
	var re5 = /^19|([2-9][0-9])$/;
	var validation = false;
	if (re5.test(document.getElementById("numeroDeExpY").value)){
		//console.log("numeroDeExpY bien");
		document.getElementById("numeroDeExpY").style.borderColor="initial";
		document.getElementById("msgFechaMY").innerHTML="✔";
		document.getElementById("msgFechaMY").style.color="green";
		validation = true;
		
	}else{
		document.getElementById("msgFechaMY").innerHTML="   ✖";
		document.getElementById("numeroDeExpY").style.borderColor="red";
		document.getElementById("msgFechaMY").style.color="red";
		
	}
	
	return validation;
}

function checkCvv(){ // Con esto comprobaremos si el Cvv es valido
	
	var re6 = /^[0-9]{3}$/i;
	var validation = false;
	if (re6.test(document.getElementById("cvv").value)){
		//console.log("cvv bien");
		document.getElementById("cvv").style.borderColor="initial";
		document.getElementById("msgCvv").innerHTML="✔";
		document.getElementById("msgCvv").style.color="green";
		validation = true;
		
	}else{
		document.getElementById("msgCvv").innerHTML="   ✖";
		document.getElementById("cvv").style.borderColor="red";
		document.getElementById("msgCvv").style.color="red";
		
	}
	
	return validation;
}

